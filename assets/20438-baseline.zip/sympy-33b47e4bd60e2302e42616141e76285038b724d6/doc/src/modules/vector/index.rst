======
Vector
======

The vector module provides tools for basic vector math
and differential calculus with respect to 3D Cartesian coordinate
systems. This documentation provides an overview of all the
features offered, and relevant API.

.. module:: sympy.vector

Guide to Vector
===============

.. toctree::
    :maxdepth: 2

    intro.rst
    basics.rst
    coordsys.rst
    fields.rst
    examples.rst
    vector_integration.rst

Vector API
==========

.. toctree::
    :maxdepth: 2

    api/classes.rst
    api/orienterclasses.rst
    api/vectorfunctions.rst

References for Vector
=====================

.. [Dyadics] https://en.wikipedia.org/wiki/Dyadics
.. [DyadicProducts] https://en.wikipedia.org/wiki/Dyadic_product
.. [DelOperator] https://en.wikipedia.org/wiki/Del
